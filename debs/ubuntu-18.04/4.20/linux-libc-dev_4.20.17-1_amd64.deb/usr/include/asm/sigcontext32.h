/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_SIGCONTEXT32_H
#define _ASM_X86_SIGCONTEXT32_H

/* This is a legacy file - all the type definitions are in sigcontext.h: */

#include <asm/sigcontext.h>

#endif /* _ASM_X86_SIGCONTEXT32_H */
